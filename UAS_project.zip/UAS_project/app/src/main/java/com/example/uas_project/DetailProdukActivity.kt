package com.example.uas_project

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.uas_project.databinding.ActivityDetailProdukBinding

class DetailProdukActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailProdukBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailProdukBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val nama = intent.getStringExtra("nama_produk")
        val gambar = intent.getIntExtra("gambar_produk", 0)

        binding.tvNamaProduk.text = nama
        binding.ivGambarProduk.setImageResource(gambar)
    }
}
