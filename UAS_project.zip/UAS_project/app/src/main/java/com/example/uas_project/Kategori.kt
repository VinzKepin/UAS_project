package com.example.uas_project

data class Kategori(
    val nama: String,
    val gambarResId: Int
)
