package com.example.uas_project

data class Produk(
    val nama: String,
    val gambarResId: Int
)
